package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class gurukulaHome {
	private static WebElement wbelement = null;
	
	public static WebElement link_login(WebDriver driver){
		wbelement = driver.findElement(By.linkText("login"));
		return wbelement;
	}
	
	public static WebElement link_register(WebDriver driver){
		wbelement = driver.findElement(By.linkText("Register a new account"));
		return wbelement;
	}

}