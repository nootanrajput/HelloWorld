package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class gurukulaLogin {
	private static WebElement wbelement = null;
	
	public static WebElement txt_username(WebDriver driver){
		wbelement = driver.findElement(By.id("username"));
		return wbelement;
	}
	
	public static WebElement txt_password(WebDriver driver){
		wbelement = driver.findElement(By.id("password"));
		return wbelement;
	}
	
	

}
