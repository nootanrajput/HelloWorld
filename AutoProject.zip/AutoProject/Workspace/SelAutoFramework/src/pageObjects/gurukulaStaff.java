package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class gurukulaStaff {
	private static WebElement wbelement = null;
	
	public static WebElement btn_CreateNewStaff(WebDriver driver){
		wbelement = driver.findElement(By.xpath("//button/span[contains(text(),'Create a new Staff')]"));
		return wbelement;
	}
	public static WebElement txt_SearchField(WebDriver driver){
		wbelement = driver.findElement(By.xpath("//input[@id='searchQuery']"));
		return wbelement;
	}
	public static WebElement btn_SearchAStaff(WebDriver driver){
		wbelement = driver.findElement(By.xpath("//button/span[contains(text(),'Search a Staff')]"));
		return wbelement;
	}
	public static WebElement txt_Name(WebDriver driver){
		wbelement = driver.findElement(By.xpath("//input[@name='name' and @ng-model='staff.name']"));
		return wbelement;
	}
	public static WebElement select_Branch(WebDriver driver){
		wbelement = driver.findElement(By.name("related_branch"));
		return wbelement;
	}
	public static WebElement btn_Save(WebDriver driver){
		wbelement = driver.findElement(By.xpath("//button/span[contains(text(),'Save') and @translate='entity.action.save']"));
		return wbelement;
	}
	public static WebElement lstitem_NameOrBranch(WebDriver driver, String nameOrCode){
		wbelement = driver.findElement(By.xpath("//td[@class='ng-binding' and contains(text(),nameOrCode)]"));
		return wbelement;
	}
	public static WebElement btn_DeleteStaff(WebDriver driver){
		wbelement = driver.findElement(By.xpath("//button[@ng-click='delete(staff.id)' and @type='submit']"));
		return wbelement;
	}
	public static WebElement lbl_deleteStaffQuestion(WebDriver driver){
		wbelement = driver.findElement(By.xpath("//p[@translate='gurukulaApp.staff.delete.question']"));
		return wbelement;
	}
	public static WebElement btn_deleteStaffConfirmation(WebDriver driver){
		wbelement = driver.findElement(By.xpath("//button[@class='btn btn-danger']/span[contains(text(),'Delete')]"));
		return wbelement;
	}
	public static WebElement btn_editStaff(WebDriver driver){
		wbelement = driver.findElement(By.xpath("//button/span[@translate='entity.action.edit' and contains(text(),'Edit')]"));
		return wbelement;
	}
	public static WebElement pgn_previousPage(WebDriver driver){
		wbelement = driver.findElement(By.xpath("//a[@href='#' and contains(text(),'<<')]"));
		return wbelement;
	}
	public static WebElement pgn_nextPage(WebDriver driver){
		wbelement = driver.findElement(By.xpath("//a[@href='#' and contains(text(),'>>')]"));
		return wbelement;
	}
}
