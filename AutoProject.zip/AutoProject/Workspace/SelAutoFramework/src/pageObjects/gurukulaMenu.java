package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class gurukulaMenu {
	private static WebElement wbelement = null;
	
	public static WebElement lbl_Account(WebDriver driver){
		wbelement = driver.findElement(By.xpath("//span[@translate='global.menu.account.main']"));
		return wbelement;
	}
	public static WebElement lbl_Logout(WebDriver driver){
		wbelement = driver.findElement(By.xpath("//span[@translate='global.menu.account.logout']"));
		return wbelement;
	}
	public static WebElement lbl_Entities(WebDriver driver){
		wbelement = driver.findElement(By.xpath("//span[contains(text(),'Entities') and @translate='global.menu.entities.main']"));
		return wbelement;
	}
	public static WebElement lbl_Branch(WebDriver driver){
		wbelement = driver.findElement(By.xpath("//span[contains(text(),'Branch') and @translate='global.menu.entities.branch']"));
		return wbelement;
	}
	public static WebElement lbl_Staff(WebDriver driver){
		wbelement = driver.findElement(By.xpath("//span[contains(text(),'Staff') and @translate='global.menu.entities.staff']"));
		return wbelement;
	}
}
