package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class gurukulaRegister {
	private static WebElement wbelement = null;
	
	public static WebElement txt_LoginName (WebDriver driver){
		wbelement = driver.findElement(By.name("login"));
		return wbelement;
	}
	public static WebElement txt_Email (WebDriver driver){
		wbelement = driver.findElement(By.name("email"));
		return wbelement;
	}
	public static WebElement txt_Password (WebDriver driver){
		wbelement = driver.findElement(By.name("password"));
		return wbelement;
	}
	public static WebElement txt_confirmPassword (WebDriver driver){
		wbelement = driver.findElement(By.name("confirmPassword"));
		return wbelement;
	}

}
