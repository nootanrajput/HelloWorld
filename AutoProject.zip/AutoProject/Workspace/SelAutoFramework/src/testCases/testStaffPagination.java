package testCases;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import pageObjects.gurukulaStaff;
import functionLiberary.applicationActions;
import functionLiberary.setupConfig;
import utilities.configValues;

public class testStaffPagination {
	public WebDriver driver;
  @Test
  public void main() throws InterruptedException {
  applicationActions.appLogin(driver, configValues.adminUsername, configValues.adminPassword);
  driver.manage().timeouts().implicitlyWait(configValues.shortWait, TimeUnit.SECONDS);
  
  applicationActions.createNewBranch(driver, "pageTest", "201");
  
  //Create 15 branch and staffs
  for(int count = 97; count<100; count++){
	  Thread.sleep(1000);
	  System.out.println("Creating user - user"+(char)count);
	  applicationActions.createNewStaff(driver, "user"+(char)count, "pageTest" );
  }
  
  //Click previous and next page:
  if(gurukulaStaff.pgn_previousPage(driver).isEnabled()){
	  gurukulaStaff.pgn_previousPage(driver).click();
  }
  Thread.sleep(2000);
  if(gurukulaStaff.pgn_nextPage(driver).isEnabled()){
	  gurukulaStaff.pgn_nextPage(driver).click();
  }
  
  //cleanup - delete staffs and branch
  for(int count = 97; count<100; count++){
	  Thread.sleep(1000);
	  System.out.println("Deleting user - user"+(char)count);
	  applicationActions.deleteStaff(driver, "user"+(char)count);
  }
  applicationActions.deleteBranch(driver, "pageTest");
  
  applicationActions.appLogout(driver);
  }
  
  @BeforeMethod
  @Parameters({"browser","gurukulaURL"})
  public void beforeMethod(String browser, String gurukulaURL) throws InterruptedException {
	  driver = setupConfig.instantiateDriver(driver, browser);
	  driver.get(gurukulaURL);
	  Thread.sleep(2000);
	  driver.manage().timeouts().implicitlyWait(configValues.mediumWait, TimeUnit.SECONDS);
	  driver.manage().window().maximize();
	  Thread.sleep(2000);
  }

  @AfterMethod
  public void afterMethod() {
	  driver.quit();
  }

}