package testCases;

import java.util.concurrent.TimeUnit;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.openqa.selenium.WebDriver;
import functionLiberary.applicationActions;
import functionLiberary.setupConfig;
import utilities.configValues;

public class createSearchEditDeleteStaff {
	public WebDriver driver;
@Test (groups = {"Staff"})
  public void main() throws InterruptedException {
	  driver.manage().timeouts().implicitlyWait(configValues.shortWait, TimeUnit.SECONDS);
	  //Test Data - create Branches required for Staff
	  applicationActions.createNewBranch(driver, "Hyderabad", "901");
	  applicationActions.createNewBranch(driver, "Netherland", "902");
	  
	  //Test 1 - Create new staff
	  applicationActions.createNewStaff(driver, "N S Rajput", "Hyderabad");
	  
	  //Test 2 - Search staff
	  applicationActions.searchStaff(driver, "N S Rajput");
	  
	  //Test 3 - Edit a Staff
	  applicationActions.editStaffName(driver, "N S Rajput", "N Rajput");
	  
	  //Test 4 - Delete a staff
	  applicationActions.deleteStaff(driver, "N Rajput");
	  
	  //Cleanup - delete branches
	  applicationActions.deleteBranch(driver, "Hyderabad");
	  applicationActions.deleteBranch(driver, "Netherland");		  
  	  }

  @BeforeMethod
  @Parameters({"browser","gurukulaURL"})
  //Login to application with admin account
  public void beforeMethod(String browser, String gurukulaURL) throws InterruptedException {
	  driver = setupConfig.instantiateDriver(driver, browser);
	  driver.get(gurukulaURL);
	  Thread.sleep(2000);
	  driver.manage().timeouts().implicitlyWait(configValues.mediumWait, TimeUnit.SECONDS);
	  driver.manage().window().maximize();
	  Thread.sleep(2000);
	  applicationActions.appLogin(driver, configValues.adminUsername, configValues.adminPassword);
	  Thread.sleep(configValues.shortWait*1000);
  }

  @AfterMethod
  public void afterMethod() throws InterruptedException {
	  //Logout from application
	  applicationActions.appLogout(driver);
	  Thread.sleep(configValues.shortWait);
	  //Close all browser instances
	  driver.quit();
  }
}