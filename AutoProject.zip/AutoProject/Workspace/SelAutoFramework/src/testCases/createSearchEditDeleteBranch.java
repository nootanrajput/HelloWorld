package testCases;

import java.util.concurrent.TimeUnit;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.openqa.selenium.WebDriver;
import functionLiberary.applicationActions;
import functionLiberary.setupConfig;
import utilities.configValues;

public class createSearchEditDeleteBranch {
	public WebDriver driver;
  @Test (groups = {"Branch"})
  public void main() throws InterruptedException {
	  driver.manage().timeouts().implicitlyWait(configValues.shortWait, TimeUnit.SECONDS);
	  //Test 1 - create Branch
	  applicationActions.createNewBranch(driver, "testBranch", "001");
	  
	  //Test 2 - Search for a branch
	  applicationActions.searchBranch(driver, "testBranch");
	  
	  //Test 3 - Edit a branch
	  applicationActions.editBranchName(driver, "testBranch", "testEBranch");
	  
	  //Test 4 - Delete the branch
	  applicationActions.deleteBranch(driver, "testEBranch");
	  
  }
  @BeforeMethod
  @Parameters({"browser","gurukulaURL"})
  //Login to application with admin account
  public void beforeMethod(String browser, String gurukulaURL) throws InterruptedException {
	  driver = setupConfig.instantiateDriver(driver, browser);
	  driver.get(gurukulaURL);
	  Thread.sleep(2000);
	  driver.manage().timeouts().implicitlyWait(configValues.mediumWait, TimeUnit.SECONDS);
	  driver.manage().window().maximize();
	  Thread.sleep(2000);
	  applicationActions.appLogin(driver, configValues.adminUsername, configValues.adminPassword);
	  Thread.sleep(configValues.shortWait*1000);
  }

  @AfterMethod
  public void afterMethod() throws InterruptedException {
	  //Logout from application
	  applicationActions.appLogout(driver);
	  Thread.sleep(configValues.shortWait);
	  //Close all browser instances
	  driver.quit();
  }

}