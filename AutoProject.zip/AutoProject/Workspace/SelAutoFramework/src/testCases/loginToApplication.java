package testCases;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import functionLiberary.applicationActions;
import functionLiberary.setupConfig;
import utilities.configValues;

public class loginToApplication {
	public WebDriver driver;
	/**
	 * @param args
	 * @throws InterruptedException 
	 */
	@Test
	public void main() throws InterruptedException {
	  //Login to application
	  applicationActions.appLogin(driver, configValues.adminUsername, configValues.adminPassword);
	  Thread.sleep(configValues.shortWait*1000);
	  //Logout from application
	  applicationActions.appLogout(driver);
	  Thread.sleep(2000);
	  System.out.println("Gurukula application login with admin/admin was successfull!");
	}
	
  @Parameters({"browser","gurukulaURL"})
  @BeforeMethod
  public void beforeMethod(String browser, String gurukulaURL) throws InterruptedException {
	  //Initialize browser instance:
	  driver = setupConfig.instantiateDriver(driver, browser);
	  driver.get(gurukulaURL);
	  Thread.sleep(2000);
	  driver.manage().timeouts().implicitlyWait(configValues.mediumWait, TimeUnit.SECONDS);
	  driver.manage().window().maximize();
	  Thread.sleep(2000);
  }

  @AfterMethod
  public void afterMethod() {
	  driver.quit();
  }
}
