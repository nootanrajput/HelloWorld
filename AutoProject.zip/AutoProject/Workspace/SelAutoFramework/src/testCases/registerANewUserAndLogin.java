package testCases;

import java.util.concurrent.TimeUnit;
import junit.framework.Assert;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import functionLiberary.applicationActions;
import functionLiberary.setupConfig;
import utilities.configValues;

@SuppressWarnings("deprecation")
public class registerANewUserAndLogin {
	public WebDriver driver;
	/**
	 * @param args
	 * @throws InterruptedException 
	 */
	@Test
	public void main() throws InterruptedException {
		Assert.assertTrue(applicationActions.registerNewUser(driver, "testuser001", "testuser01@dummy.com", "(hang3_m3!GK"));
		//If user is craeted, proceed with login
		System.out.println("User successfully created");
		//Login with new user
		driver.get(configValues.gurukulaURL);
		applicationActions.appLogin(driver, "testuser001", "(hang3_m3!GK");
	}
	
	  @Parameters({"browser","gurukulaURL"})
	  @BeforeMethod
	  public void beforeMethod(String browser, String gurukulaURL) throws InterruptedException {
		  //Initialize browser instance:
		  driver = setupConfig.instantiateDriver(driver, browser);
		  driver.get(gurukulaURL);
		  Thread.sleep(2000);
		  driver.manage().timeouts().implicitlyWait(configValues.mediumWait, TimeUnit.SECONDS);
		  driver.manage().window().maximize();
		  Thread.sleep(2000);
	  }

	  @AfterMethod
	  public void afterMethod() {
		  driver.quit();
	  }
}