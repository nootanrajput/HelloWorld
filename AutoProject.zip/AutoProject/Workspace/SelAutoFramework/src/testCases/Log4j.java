package testCases;

import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import functionLiberary.applicationActions;
import functionLiberary.setupConfig;

import utilities.configValues;
 
public class Log4j {
 
	private static WebDriver driver;

	private static Logger Log = Logger.getLogger(Log4j.class.getName());
 
	public static void main(String[] args) throws InterruptedException {
 
		DOMConfigurator.configure("log4j.xml");
 
		driver = setupConfig.instantiateDriver(driver, configValues.browserName);
        Log.info("New driver instantiated");
 
        //Put a Implicit wait, this means that any search for elements on the page could take the time the implicit wait is set for before throwing exception
        Log.info("Implicit wait applied on the driver for 10 seconds");
 
        //Launch the Online Store Website
 
        driver.get(configValues.gurukulaURL);
        driver.manage().window().maximize();
 
        Log.info("Web application launched");
 
        // Find the element that's ID attribute is 'account'(My Account)
 
        driver.findElement(By.linkText("login")).click();
 
        Log.info("Click action performed on login link");
 
        // Find the element that's ID attribute is 'log' (Username)
 
        // Enter Username on the element found by above desc.
 
        driver.findElement(By.id("username")).sendKeys("admin");
 
        Log.info("Username entered in the Username text box");
 
        // Find the element that's ID attribute is 'pwd' (Password)
 
        // Enter Password on the element found by the above desc.
 
        driver.findElement(By.id("password")).sendKeys("admin");
 
        Log.info("Password entered in the Password text box");
 
        // Now submit the form. WebDriver will find the form for us from the element
 
        driver.findElement(By.id("password")).submit();
 
        Log.info("Click action performed on Submit button");
 
        // Print a Log In message to the screen
 
        System.out.println(" Login Successfull, Logout now!");
 
         // Find the element that's ID attribute is 'account_logout' (Log Out)
        applicationActions.appLogout(driver);
 
        Log.info("Click action performed on Log out link");
 
        // Close the driver
        driver.quit();
        System.out.println(" Logged out and browser closed! Check C:\\AutoProject\\Workspace\\SelAutoFramework\\logfile.log for Log4j logs");
        Log.info("Browser closed");
	} 
}