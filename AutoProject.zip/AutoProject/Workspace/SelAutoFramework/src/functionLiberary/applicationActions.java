package functionLiberary;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import pageObjects.gurukulaHome;
import pageObjects.gurukulaLogin;
import pageObjects.gurukulaMenu;
import pageObjects.gurukulaRegister;
import pageObjects.gurukulaBranch;
import pageObjects.gurukulaStaff;
import utilities.configValues;

public class applicationActions {
	//appLogin - Navigate to login page - enter credentials and login
	public static void appLogin(WebDriver driver, String userName, String password){
		gurukulaHome.link_login(driver).click();
		
		gurukulaLogin.txt_username(driver).sendKeys(userName);
		gurukulaLogin.txt_password(driver).sendKeys(password);
		gurukulaLogin.txt_password(driver).submit();
	}
	
	//appLogout - Click on Account - Logout.
	public static void appLogout(WebDriver driver){
		gurukulaMenu.lbl_Account(driver).click();
		gurukulaMenu.lbl_Logout(driver).click();
	}
	
	//registerNewUser - creates a new user
	public static Boolean registerNewUser(WebDriver driver, String userName, String Email, String Password){
		gurukulaHome.link_register(driver).click();
		
		gurukulaRegister.txt_LoginName(driver).sendKeys(userName);
		gurukulaRegister.txt_Email(driver).sendKeys(Email);
		gurukulaRegister.txt_Password(driver).sendKeys(Password);
		gurukulaRegister.txt_confirmPassword(driver).sendKeys(Password);
		
		gurukulaRegister.txt_confirmPassword(driver).submit();
		
		try {
			Boolean isPresent = driver.findElements(By.xpath("//div[@translate='register.messages.error.fail']")).size() > 0;
			System.out.println("User registration failed. Failure message in UI isPresent = " + isPresent);
			return(false);
		}
		catch(NoSuchElementException e){
			System.out.println("User registration failed.");
			return(true);
		}
	}
	
	//checkElementExist - To verify if element exists using xpath
	public static Boolean checkElementExist(WebDriver driver1, String xpath)
	{
	    try
	    {
	     //Explicit wait to check if element exist for 5s
	    	WebDriverWait wait = new WebDriverWait(driver1, 5);
	    	WebElement element = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpath)));
	    	System.out.println(element.getText());
	        return true;
	    }
	    catch (NoSuchElementException e)
	    {
	        return false;
	    }
	}
	
	//createNewBranch - Creates a new branch
	public static Boolean createNewBranch(WebDriver driver, String branchName, String branchCode) throws InterruptedException{
		gurukulaMenu.lbl_Entities(driver).click();
		gurukulaMenu.lbl_Branch(driver).click();
		
		gurukulaBranch.btn_CreateNewBranch(driver).click();
		
		gurukulaBranch.txt_Name(driver).sendKeys(branchName);
		gurukulaBranch.txt_Code(driver).sendKeys(branchCode);
		Thread.sleep(2000);
		gurukulaBranch.btn_Save(driver).click();
		Thread.sleep(2000);
		return (applicationActions.searchBranch(driver, branchName));
	}
	
	//searchBranch - searches for a branch name in branch list
	public static Boolean searchBranch(WebDriver driver, String searchQuery) throws InterruptedException{
		gurukulaMenu.lbl_Entities(driver).click();
		gurukulaMenu.lbl_Branch(driver).click();
		Thread.sleep(2000);
		gurukulaBranch.txt_SearchField(driver).clear();
		gurukulaBranch.txt_SearchField(driver).sendKeys(searchQuery);
		gurukulaBranch.btn_SearchABranch(driver).click();
		Thread.sleep(2000);
		try {
			System.out.println("Branch - " + gurukulaBranch.lstitem_NameOrCode(driver, searchQuery).getText() + " is available!");
			return(true);
		}
		catch(NoSuchElementException e){
			System.out.println("Branch not found in the list!");
			return(false);
		}
	}
	
	//editBranch - searches a branch with name and edits
	public static Boolean editBranchName(WebDriver driver, String currentName, String newName) throws InterruptedException{
		Boolean status = false;
		if (applicationActions.searchBranch(driver, currentName)){
			gurukulaBranch.btn_EditBranch(driver).click();
			System.out.println("Branch found, edit button clicked");
			Thread.sleep(configValues.shortWait*1000);
			if(gurukulaBranch.txt_Name(driver).isDisplayed()){
				System.out.println("Create or edit page appeared...");
				gurukulaBranch.txt_Name(driver).clear();
				gurukulaBranch.txt_Name(driver).sendKeys(newName);
				gurukulaBranch.btn_Save(driver).click();
				System.out.println("New name saved...");
			}
		}
		Thread.sleep(configValues.shortWait*1000);
		//Search again and it should not be present now:
		if (applicationActions.searchBranch(driver, newName)){
			System.out.println("Branch name modified...");
			status = true;
		}
		return status;
	}
	
	//deleteBranch  - Deletes a branch
	public static Boolean deleteBranch(WebDriver driver, String branchNameOrCode) throws InterruptedException{
		Boolean status = false;
		if (applicationActions.searchBranch(driver, branchNameOrCode)){
			gurukulaBranch.btn_DeleteBranch(driver).click();
			System.out.println("Branch found, delete button clicked");
			Thread.sleep(configValues.shortWait*1000);
			if(gurukulaBranch.lbl_deleteBranchQuestion(driver).isDisplayed()){
				System.out.println("Confirm deletion?....");
				gurukulaBranch.btn_DeleteBranchConfirmation(driver).click();
				System.out.println("Deletion confirmed.");
			}
		}
		Thread.sleep(configValues.shortWait*1000);
		//Search again and it should not be present now:
		if (applicationActions.searchBranch(driver, branchNameOrCode)){
			System.out.println("Branch deletion failed.");
		}
		else{
			status = true;
		}
		return status;
	}

	//createNewBranch - Creates a new branch
	public static Boolean createNewStaff(WebDriver driver, String staffName, String branchName) throws InterruptedException{
		//Go to staff page:
		gurukulaMenu.lbl_Entities(driver).click();
		gurukulaMenu.lbl_Staff(driver).click();
		
		//Click create new staff button
		Thread.sleep(2000);
		gurukulaStaff.btn_CreateNewStaff(driver).click();
		
		//Enter staff name and set branch
		Thread.sleep(2000);
		gurukulaStaff.txt_Name(driver).sendKeys(staffName);
		Select branchMenu = new Select(gurukulaStaff.select_Branch(driver));
		branchMenu.selectByVisibleText(branchName);

		Thread.sleep(2000);
		gurukulaStaff.btn_Save(driver).click();
		Thread.sleep(2000);
		
		return (applicationActions.searchStaff(driver, staffName));
	}
	
	//searchBranch - searches for a branch name in branch list
	public static Boolean searchStaff(WebDriver driver, String staffName) throws InterruptedException{
		gurukulaMenu.lbl_Entities(driver).click();
		gurukulaMenu.lbl_Staff(driver).click();
		
		Thread.sleep(2000);
		gurukulaStaff.txt_SearchField(driver).clear();
		gurukulaStaff.txt_SearchField(driver).sendKeys(staffName);
		Thread.sleep(1000);
		gurukulaStaff.btn_SearchAStaff(driver).click();
		Thread.sleep(2000);
		
		try {
			System.out.println("Staff - " + gurukulaStaff.lstitem_NameOrBranch(driver, staffName).getText() + " is available!");
			return(true);
		}
		catch(NoSuchElementException e){
			System.out.println("Staff not found in the list!");
			return(false);
		}
	}
	
	//editStaffName - searches a branch with name and modifies with newName
	public static Boolean editStaffName(WebDriver driver, String currentName, String newName) throws InterruptedException{
		Boolean status = false;
		if (applicationActions.searchStaff(driver, currentName)){
			gurukulaStaff.btn_editStaff(driver).click();
			System.out.println("Staff found, edit button clicked");
			Thread.sleep(configValues.shortWait*1000);
			if(gurukulaStaff.txt_Name(driver).isDisplayed()){
				System.out.println("Create or edit page appeared...");
				gurukulaStaff.txt_Name(driver).clear();
				gurukulaStaff.txt_Name(driver).sendKeys(newName);
				gurukulaStaff.btn_Save(driver).click();
				System.out.println("New name saved...");
			}
		}
		Thread.sleep(configValues.shortWait*1000);
		//Search again and it should not be present now:
		if (applicationActions.searchStaff(driver, newName)){
			System.out.println("Staff name modified...");
			status = true;
		}
		return status;
	}
	
	//deleteStaff
	public static Boolean deleteStaff(WebDriver driver, String staffName) throws InterruptedException{
		Boolean status = false;
		if (applicationActions.searchStaff(driver, staffName)){
			gurukulaStaff.btn_DeleteStaff(driver).click();
			System.out.println("Staff found, delete button clicked");
			Thread.sleep(configValues.shortWait*1000);
			if(gurukulaStaff.lbl_deleteStaffQuestion(driver).isDisplayed()){
				System.out.println("Confirm deletion?....");
				gurukulaStaff.btn_deleteStaffConfirmation(driver).click();
				System.out.println("Deletion confirmed.");
			}
		}
		Thread.sleep(configValues.shortWait*1000);
		//Search again and it should not be present now:
		if (applicationActions.searchStaff(driver, staffName)){
			System.out.println("Staff deletion failed.");
		}
		else{
			status = true;
		}
		return status;
	}
}