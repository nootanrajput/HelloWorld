package functionLiberary;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import utilities.configValues;

public class setupConfig {
	public static WebDriver instantiateDriver(WebDriver driver, String browserType) throws InterruptedException{
		String brType = browserType.toLowerCase();
		if(brType.equals("firefox")){
			driver = new FirefoxDriver();
			driver.manage().timeouts().implicitlyWait(configValues.mediumWait, TimeUnit.SECONDS);
		}
		else if(brType.equals("chrome")){
			System.setProperty("webdriver.chrome.driver", configValues.baseDirectory+"\\AutoProject\\Liberaries\\chromedriver.exe");
			driver = new ChromeDriver();
			driver.manage().timeouts().implicitlyWait(configValues.mediumWait, TimeUnit.SECONDS);
		}
		else if(brType.equals("ie") || brType.equals("internet explorer")){
			System.setProperty("webdriver.ie.driver", configValues.baseDirectory+"\\AutoProject\\Liberaries\\IEDriverServer.exe");
			DesiredCapabilities caps = DesiredCapabilities.internetExplorer();
			caps.setCapability("ignoreZoomSetting", true);
			driver = new InternetExplorerDriver(caps);
			Thread.sleep(configValues.mediumWait*1000);
		}
		else{
			System.out.println("Browser type = " + brType + " so using default browser as FIREFOX");
			driver = new FirefoxDriver();
			driver.manage().timeouts().implicitlyWait(configValues.mediumWait, TimeUnit.SECONDS);
		}		
		return driver;
	}

}
