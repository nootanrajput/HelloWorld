package utilities;

public class configValues {
	public static final String baseDirectory = "C:";//C:, D:
	public static final String adminUsername = "admin";
	public static final String adminPassword = "admin";
	public static final Integer shortWait = 5;
	public static final Integer mediumWait = 10;
	public static final Integer longWait = 15;
	public static final String gurukulaURL = "http://127.0.0.1:8080";//Only used in Log4j.java test
	public static final String browserName = "chrome";//firefox;chrome;ie & Only used in Log4j.java test
}
